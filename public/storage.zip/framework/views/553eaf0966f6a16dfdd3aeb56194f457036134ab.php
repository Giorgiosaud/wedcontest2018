<div class="d-flex flex-column h-mid align-items-center justify-content-center text-light" style="background-image:url(<?php echo e(asset('storage/contest/rethinking-plastic/backgroundImage.jpg')); ?> )">
	<div class="container text-center">
        <img src="<?php echo e(asset('storage/contest/rethinking-plastic/enLogo.jpg')); ?>" width="300" alt="Reinventando el Plástico">
        <div class="cabecera"><?php echo app('translator')->getFromJson('navbar.adminHeader'); ?></div>
    </div>
</div>