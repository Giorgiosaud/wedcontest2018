<?php $__env->startSection('intro'); ?>
    <div id="IntroSection" style="background-image:url('<?php echo e($contest->intro_image); ?>')"
         class="flex-col flex font-serif h-screen items-center justify-center text-white bg-cover"
    >
        <div class="font-hairline text-5xl" data-depth="0.2"><?php echo e($contest->year); ?> World Enviroment Day</div>
        <div class="font-hairline text-3xl" data-depth="0.6">Drawing Contest</div>
    </div>
<?php $__env->stopSection(); ?>