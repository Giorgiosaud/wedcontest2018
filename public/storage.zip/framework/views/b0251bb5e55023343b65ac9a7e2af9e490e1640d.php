<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.assets.headerStandart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container py-4">
	<div class="row py-4">
		<h1><?php echo app('translator')->getFromJson('contestants.contestants'); ?></h1>
	</div>
	<div class="row">
		<?php $__currentLoopData = $contestants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contestant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<contestant-card edit-link="<?php echo e(route('contestant.edit',$contestant->id)); ?>" :contestant="<?php echo e($contestant); ?>" :key="<?php echo e($contestant->id); ?>"></contestant-card>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div class="row">
		<a class="btn btn-wedcontest is-green w-full" href="<?php echo e(route('contestant.create')); ?>"><?php echo app('translator')->getFromJson('contestants.addNew'); ?></a>
	</div>
</div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>