<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link href="//fonts.googleapis.com/css?family=Nixie+One|PT+Sans:400,700" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.App = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'user' => Auth::user(),
            'signedIn' => Auth::check(),
            'locale'=> LaravelLocalization::getCurrentLocale()
        ]); ?>;
    </script>

    <script src='https://www.google.com/recaptcha/api.js'></script>

    <?php echo $__env->yieldContent('head'); ?>
</head>

<body class="font-sans">
<div id="app">
    <?php echo $__env->make('layouts.assets.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->startComponent('components.header'); ?>
        <?php $__env->slot('image'); ?>
            <?php echo $__env->yieldContent('mainImage',asset('/images/Home/ContestIntro.jpg')); ?>
        <?php $__env->endSlot(); ?>
        <?php echo $__env->yieldContent('mainTitle','Wedcontest'); ?>
        <?php $__env->slot('height'); ?>
        <?php echo $__env->yieldContent('height','h-64'); ?>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('year'); ?>
            <?php echo $__env->yieldContent('year','2018'); ?>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <div class="container mx-auto">
        <div class="flex">
            
                
            

            <div class="px-10 bg-white flex-1">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            
        </div>
    </div>

    <flash message="<?php echo e(session('flash')); ?>"></flash>

</div>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
