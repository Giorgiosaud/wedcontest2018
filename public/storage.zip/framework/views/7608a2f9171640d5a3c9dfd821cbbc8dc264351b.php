<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.assets.headerAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pt-6">
   <div class="content">
   	<users></users>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>