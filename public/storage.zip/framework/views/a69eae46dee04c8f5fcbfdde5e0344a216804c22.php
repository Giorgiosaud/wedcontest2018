<?php $__env->startSection('content'); ?>
<div class="flex mt-4">
	<div class="w-1/4">
		<a href="/my-participants">My Participants</a>
	</div>
	<div class="w-3/4"><h1><?php echo app('translator')->getFromJson('profile.my_profile'); ?></h1>
		<?php if(auth()): ?>
		<edit-my-profile :profile="<?php echo e(auth()->user()); ?>"></edit-my-profile>
		<?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>