<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column h-100vh align-items-center justify-content-center text-light" style="background-image:url(<?php echo e($contest->background_image); ?>)">
    <div class="mb-4" data-depth="0.6">Drawing Contest <?php echo e($contest->topic); ?></div>
    <div class="mb-4" data-depth="0.2"><?php echo $contest->description; ?></div>
</div>

<article class="container">
    <div class="d-flex align-items-center justify-left py-4">
        <h2><?php echo e($contest->topic); ?></h2>
        <div class="d-flex align-items-center ml-auto justify-center">
            <a href="<?php echo e(route('contest.edit',$contest->slug)); ?>">
                <div class="badge badge-pill badge-warning mx-1">
                    <?php echo app('translator')->getFromJson('contests.edit'); ?>
                </div>
            </a>
            
            <div class="badge badge-pill badge-primary mx-1">
                <?php echo e($contest->year); ?>

            </div>
            
            <?php if($contest->active): ?>
            <div class="badge badge-pill badge-primary mx-1">
                Active
            </div>
            <?php else: ?>
            <div class="badge badge-pill badge-warning mx-1">
                Inactive
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="py-4">
        <?php echo $contest->description; ?>

    </div>
    
    
<ul class="list-group">
    <?php $__currentLoopData = $contest->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item"><?php echo e($category->name); ?>

        <span class="badge badge-primary badge-pill">
            Max Age <?php echo e($category->max_age); ?>

        </span>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</article>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>