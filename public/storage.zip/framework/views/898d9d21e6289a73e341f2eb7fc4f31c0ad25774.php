<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column h-100vh align-items-center justify-content-center text-light" style="background-image:url(<?php echo e($contest->background_image); ?>)">
    <div class="container text-center my-4">
        <img src="/storage/<?php echo e($contest->logo_image); ?>" alt="<?php echo e($contest->topic); ?>" style="max-width:300px">
        <?php if(auth()->check()): ?>
            <?php if(auth()->user()->confirmed): ?>
                <h1 class="my-4"><?php echo app('translator')->getFromJson('navbar.header_confirmed'); ?></h1>
            <?php else: ?>
                <h1 class="my-4"><?php echo app('translator')->getFromJson('navbar.unconfirmed_1'); ?></br><?php echo app('translator')->getFromJson('navbar.unconfirmed_2'); ?></h1>  
            <?php endif; ?>            
        <?php else: ?>
            <h1 class="my-4"><?php echo app('translator')->getFromJson('navbar.header'); ?></h1>
        <?php endif; ?>
        

    </div>
    <div class="d-flex justify-content-center">

        <?php if(auth()->check()): ?>
        <?php if(auth()->user()->confirmed): ?>
        <a class="btn btn-wedcontest is-green w-full" href="<?php echo e(route('mycontestant.create')); ?>"><?php echo app('translator')->getFromJson('contestants.addNew'); ?></a>

        <?php else: ?>
        <p class="border-dashed border-light p-3"><?php echo app('translator')->getFromJson('contests.confirm_email'); ?></p>
        <?php endif; ?>
        <?php else: ?>
        <a class="btn btn-primary btn-wedcontest mr-4" href="<?php echo e(route("login")); ?>"><?php echo app('translator')->getFromJson('contests.login_button'); ?></a>
        <a class="btn btn-primary btn-wedcontest mr-4" href="<?php echo e(route("register")); ?>" ><?php echo app('translator')->getFromJson('contests.register_button'); ?></a>
        <?php endif; ?>
    </div>
    <div class="d-flex justify-content-center">
        <a class="btn btn-wedcontest-2 mt-4" href="<?php echo app('translator')->getFromJson('contests.faqlink'); ?>" target="_blank"><?php echo app('translator')->getFromJson('contests.FAQ'); ?></a>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>