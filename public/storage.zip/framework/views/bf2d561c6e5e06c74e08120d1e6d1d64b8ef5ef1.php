<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column h-mid align-items-center justify-content-center text-light" style="background-image:url('/images/defaultBg.jpg')">
	<div class="text-5xl" data-depth="0.6"><?php echo app('translator')->getFromJson('contests.new_contest'); ?></div>
</div>
<div class="container py-4">
	<article>
		<?php echo $__env->make('contests.assets.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</article>
</div>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>