<nav id="main-menu-container" class="fixed w-full pin-t py-4">
    <div class="container mx-auto flex justify-between items-center text-blue-lightest pl-6">
        <div>
            <h1 class="font-normal text-2xl">
                <a href="/" class="text-blue-lightest flex items-center">
                    <?php echo $__env->make('svgs.logo', ['class' => 'mr-2'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo e(config('app.name', 'Council')); ?>

                </a>
            </h1>
        </div>

        <div class="flex" v-cloak>
            
                
                    
                           
                           
                           
                           
                

                
            

            <?php if(auth()->check()): ?>
                <user-notifications></user-notifications>

                
                <div>
                    <dropdown>
                        <div slot="heading"
                             class="rounded-full bg-blue-darkest w-10 h-10 flex items-center justify-center cursor-pointer relative z-10"
                        >


                                 
                        </div>

                        <template slot="links">
                            <li class="text-sm pb-3">
                                
                            </li>

                            <?php if(Auth::user()->isAdmin()): ?>
                                <li class="text-sm pb-3">
                                    
                                </li>
                            <?php endif; ?>

                            <li class="text-sm">
                                <logout-button route="<?php echo e(route('logout')); ?>" class="link">Logout</logout-button>
                            </li>
                        </template>
                    </dropdown>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>