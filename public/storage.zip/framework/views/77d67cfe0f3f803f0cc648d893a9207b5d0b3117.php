            

<h1>
        <?php echo e($exception->getStatusCode()); ?>

    </h1>
 
    <p>
        <?php if(!empty($exception->getMessage())): ?>
            <?php echo e($exception->getMessage()); ?>

        <?php else: ?>
            <?php echo e(\Symfony\Component\HttpFoundation\Response::$statusTexts[$exception->getStatusCode()]); ?>

        <?php endif; ?>
    </p>