<?php $__env->startSection('mainImage'); ?>
<?php echo e($contest->intro_image); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainTitle'); ?>
<?php echo e($contest->topic); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('year'); ?>
<?php echo e($contest->year); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<article>
    <div class="flex items-center justify-left">
        <h2><?php echo e($contest->topic); ?></h2>
        <div class="flex items-center justify-end flex-1 mt-4 px-4 text-xs">
            <a href="<?php echo e(route('contests.edit',$contest->slug)); ?>">
                <div class="bg-green-lighter hover:bg-green text-white font-light mr-2 py-2 px-4 rounded-full">
                    <?php echo app('translator')->getFromJson('contests.edit'); ?>
                </div>
            </a>
            
            <div class="bg-blue-lighter hover:bg-blue-light text-white font-light mr-2 py-2 px-4 rounded-full">
                <?php echo e($contest->year); ?>

            </div>
            
            <?php if($contest->active): ?>
            <div class="bg-blue hover:bg-blue-dark text-white font-light py-2 px-4 rounded-full">
                Active
            </div>
            <?php else: ?>
            <div class="bg-red hover:bg-red-dark text-white font-bold py-2 px-4 rounded-full">
                Inactive
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="pt-4">
        <?php echo $contest->description; ?>

    </div>
    
    
</article>
<ul>
    <?php $__currentLoopData = $contest->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item d-flex justify-content-between align-items-center"><?php echo e($category->name); ?>

        <span class="badge badge-primary badge-pill">
            <?php echo e($category->max_age); ?>

        </span>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>