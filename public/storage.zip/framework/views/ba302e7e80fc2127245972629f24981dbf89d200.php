<aside class="bg-grey-lightest p-6 pr-10 border-l border-r w-64">
    <?php echo $__env->yieldContent('sidebar-top'); ?>

    <div class="widget border-b-0">
    </div>

    <div class="widget">
        <h4 class="widget-heading">Browse</h4>

        <ul class="list-reset text-sm">
            <li class="pb-3">
                <a href="/threads" class="flex items-center text-grey-darkest hover:text-blue hover:font-bold <?php echo e(Request::is('threads') && ! Request::query() ? 'text-blue font-bold' : ''); ?>">
                    <?php echo $__env->make('svgs.icons.all-threads', ['class' => 'mr-3 text-grey'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    All Threads
                </a>
            </li>
        </ul>
    </div>

</aside>

            
                
                    
                       
                    
                        
                             
                             

                        
                    
                
            

            
                
                    
                    
                
            

            
                
                    
                    
                
            
        
    

    
        
            

            
                
                    
                        
                            
                        
                    
                
            
        
    

