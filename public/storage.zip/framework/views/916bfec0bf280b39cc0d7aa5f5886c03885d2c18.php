<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.assets.headerStandart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container my-4">
    <representant-registration-form  post-to="<?php echo e(route('register')); ?>"></representant-registration-form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>