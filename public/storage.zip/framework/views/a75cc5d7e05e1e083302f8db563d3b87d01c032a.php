<?php $__env->startSection('mainTitle'); ?>
Register Contestant
<?php $__env->stopSection(); ?>
<?php $__env->startSection('year'); ?>
2018
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="pt-6">
   <div class="content">
   <contestant-registration-form :categories="<?php echo e($categories); ?>"></contestant-registration-form>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>