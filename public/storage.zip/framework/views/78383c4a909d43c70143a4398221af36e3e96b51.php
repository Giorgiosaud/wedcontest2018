<?php $__env->startSection('content'); ?>

<article>
    <div class="pt-4 pb-4">
        <h2><?php echo app('translator')->getFromJson('contests.new_contest'); ?></h2>
    </div>
    <?php echo $__env->make('contests.assets.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</article>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>