<div class="d-flex flex-column h-mid align-items-center justify-content-center text-light" style="background-image:url(<?php echo e($contest->background_image); ?>)">
	<div class="container text-center">
        <img src="/storage/<?php echo e($contest->logo_image); ?>" width="300" alt="Reinventando el Plástico">
        <div class="cabecera"><?php echo app('translator')->getFromJson('navbar.header'); ?></div>
    </div>
</div>