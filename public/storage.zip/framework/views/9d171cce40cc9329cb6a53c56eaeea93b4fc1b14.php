<nav class="navbar navbar-expand-md navbar-dark bg-wedcontest fixed-top">
    <div class="container">
        <a class="navbar-brand" href="/">
            <img src="/images/logo.png" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo app('translator')->getFromJson('navbar.topic_link'); ?>">
                    <?php echo app('translator')->getFromJson('navbar.topic'); ?>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="LearningCenterDD" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo app('translator')->getFromJson('navbar.learning_center'); ?></a>
                <div class="dropdown-menu" aria-labelledby="LearningCenterDD">
                    <a href="<?php echo app('translator')->getFromJson('navbar.categories_link'); ?>" class="dropdown-item">
                        <?php echo app('translator')->getFromJson('navbar.categories'); ?>
                    </a>
                    <a href="<?php echo app('translator')->getFromJson('navbar.articles_link'); ?>" class="dropdown-item">
                        <?php echo app('translator')->getFromJson('navbar.articles'); ?>
                    </a>
                    <a href="<?php echo app('translator')->getFromJson('navbar.link_links'); ?>" class="dropdown-item">
                        <?php echo app('translator')->getFromJson('navbar.links'); ?>
                    </a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="aboutTheContestDD" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo app('translator')->getFromJson('navbar.about'); ?></a>
                <div class="dropdown-menu" aria-labelledby="aboutTheContestDD">
                    <a href="<?php echo app('translator')->getFromJson('navbar.history_link'); ?>" class="dropdown-item"> 
                        <?php echo app('translator')->getFromJson('navbar.history'); ?>
                    </a>
                    <a href="<?php echo app('translator')->getFromJson('navbar.rules_link'); ?>" class="dropdown-item">
                        <?php echo app('translator')->getFromJson('navbar.rules'); ?>
                    </a>
                    <a href="<?php echo app('translator')->getFromJson('navbar.winners_link'); ?>" class="dropdown-item">
                        <?php echo app('translator')->getFromJson('navbar.winners'); ?>
                    </a>
                    <a href="<?php echo app('translator')->getFromJson('navbar.judges_link'); ?>" class="dropdown-item">
                        <?php echo app('translator')->getFromJson('navbar.judges'); ?>
                    </a>

                </div>
            </li>

            <?php if(auth()->check()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(auth()->user()->name); ?> <?php echo e(auth()->user()->last_name); ?>

                </a>
                <div class="dropdown-menu" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('mycontestants.index')); ?>"><?php echo app('translator')->getFromJson('contestants.myParticipants'); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route('mycontestant.create')); ?>" class="link"><?php echo app('translator')->getFromJson('contestants.addNew'); ?></a>
                    <div class="dropdown-divider"></div>
                    
                    <?php if(auth()->user()->isAdmin()): ?>
                    
                    <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>" class="link">List Of Representants and Contestants</a>

                    
                    <div class="dropdown-divider"></div>
                    <?php endif; ?>
                    <logout-button route="<?php echo e(route('logout')); ?>" class="dropdown-item"><?php echo app('translator')->getFromJson('contests.logout'); ?></logout-button>

                </div>
            </li>

            <?php endif; ?>
            <li class="nav-item d-flex align-items-center">

                <a class="n-link" href="<?php echo e(route('lang.switch',[\Request::route()->getName(),app()->getLocale()])); ?>">
                    <?php if(__('contests.otherLang')=="Español"): ?>
                    <img src="/images/flags/ES.png" alt="<?php echo app('translator')->getFromJson('navbar.contests.otherLang'); ?>">
                    <?php else: ?>
                    <img src="/images/flags/US.png" alt="<?php echo app('translator')->getFromJson('navbar.contests.otherLang'); ?>">
                    <?php endif; ?>
                </a>
            </li>
        </ul>
    </div>
</div>
</nav>