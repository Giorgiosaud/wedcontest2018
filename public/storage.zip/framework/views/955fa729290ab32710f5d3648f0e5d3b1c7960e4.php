<?php $__env->startComponent('mail::message'); ?>
    # Un Ultimo Paso

    Solo necesitamos confirmar que tu correo no le pertenece a un Robot y que los recibes bien.
    ¿Nos entiendes cierto? , Cool.
<?php $__env->startComponent('mail::button',  ['url' => url('/register/confirm?token=' . $user->confirmation_token)]); ?>
Confirma tu Correo
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
