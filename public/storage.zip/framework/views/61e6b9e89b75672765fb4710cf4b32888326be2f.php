<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.assets.headerStandart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pt-6">
   <div class="content">
   <contestant-registration-form post-to="<?php echo e(route('contestant.store')); ?>" :categories="<?php echo e($categories); ?>"></contestant-registration-form>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>