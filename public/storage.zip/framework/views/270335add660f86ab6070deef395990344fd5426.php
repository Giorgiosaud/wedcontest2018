<?php $__env->startComponent('mail::message'); ?>

# <?php echo app('translator')->getFromJson('reset.salutation'); ?>


<?php echo app('translator')->getFromJson('reset.message'); ?>



<?php if(isset($actionText)): ?>
<?php
    switch ($level) {
        case 'success':
            $color = 'green';
            break;
        case 'error':
            $color = 'red';
            break;
        default:
            $color = 'blue';
    }
?>
<?php $__env->startComponent('mail::button', ['url' => $actionUrl, 'color' => $color]); ?>
<?php echo app('translator')->getFromJson('reset.button'); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<?php echo app('translator')->getFromJson('reset.outro'); ?>


<?php echo app('translator')->getFromJson('reset.regards'); ?>,<br>WED CONTEST TEAM


<?php if(isset($actionText)): ?>
<?php $__env->startComponent('mail::subcopy'); ?>
<?php echo app('translator')->getFromJson(
    "If you’re having trouble clicking the \":actionText\" button, copy and paste the URL below\n".
    'into your web browser: [:actionURL](:actionURL)',
    [
        'actionText' => $actionText,
        'actionURL' => $actionUrl
    ]
); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
