<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
        	<img src="<?php echo e($logo); ?>" width="100">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
