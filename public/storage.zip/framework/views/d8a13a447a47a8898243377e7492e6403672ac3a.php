<?php $__env->startSection('mainImage'); ?>
<?php echo e($contest->intro_image); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainTitle'); ?>
<?php echo e($contest->topic); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('year'); ?>
<?php echo e($contest->year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="pt-6">
    
</div>
    <?php if(auth()->check()): ?>
        <?php if(auth()->user()->confirmed): ?>
            <button class="btn is-green w-full" @click="$modal.show('new-thread')">Add New Thread</button>
        <?php else: ?>
            <p class="text-xs text-grey-dark font-bold border border-dashed border-grey-dark p-3"><?php echo app('translator')->getFromJson('contests.confirm_email'); ?></p>
        <?php endif; ?>
    <?php else: ?>
<a class="btn is-green w-full tracking-wide" href="<?php echo e(route("login")); ?>"><?php echo app('translator')->getFromJson('contests.login_button'); ?></a>
        <a class="btn is-green w-full tracking-wide mt-4" href="<?php echo e(route("register")); ?>" ><?php echo app('translator')->getFromJson('contests.register_button'); ?></a>
    <?php endif; ?>

    <div v-cloak>
        <?php echo $__env->make('modals.all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>