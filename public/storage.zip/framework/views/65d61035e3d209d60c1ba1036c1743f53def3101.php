<svg xmlns="http://www.w3.org/2000/svg" width="19" height="14" viewBox="0 0 19 14" class="<?php echo e($class ?? ''); ?>">
    <g fill="none" fill-rule="evenodd">
        <path d="M0-3h19v19H0z"/>
        <path fill="#C1C1CE" d="M10.292 6.5h5.541v1.187h-5.541V6.5zm0-1.98h5.541v1.188h-5.541V4.521zm0 3.96h5.541v1.187h-5.541V8.479zM16.625.166H2.375C1.505.167.792.879.792 1.75v10.292c0 .87.712 1.583 1.583 1.583h14.25c.87 0 1.583-.713 1.583-1.583V1.75c0-.87-.712-1.583-1.583-1.583zm0 11.875H9.5V1.75h7.125v10.292z"/>
    </g>
</svg>
